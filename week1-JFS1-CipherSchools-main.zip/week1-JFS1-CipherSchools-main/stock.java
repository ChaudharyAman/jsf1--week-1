public class stock {
    public String iamAccessibleEveryWhere;
    private String iamAccessibleOnlyHere;
    protected  String iamAccessibleToDerivedClass;
    String iamAccessibletoSamePackage;
}
