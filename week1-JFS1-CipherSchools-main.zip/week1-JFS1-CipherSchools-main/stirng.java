public class stirng {
    public static void main(String[] args) {
        char ch='A'; //65
        // while loop
        while(ch<=90) {
            System.out.print(ch+ " ");
            ch++;
        }

        //Do while 
        char ch1='A';
        do {
            System.out.print(ch1+" ");
            ch1++;
        } while (ch1<='Z');
    }
}

